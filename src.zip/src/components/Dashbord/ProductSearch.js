import React, { useState } from 'react';
import axios from 'axios';
import './ProductSearch.css';
const ProductSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const token = localStorage.getItem('token');

  const handleChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.get(`http://localhost:8089/products/search?name=${searchTerm}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setSearchResults(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error searching products:', error);
      setLoading(false);
    }
  };

  return (
    <div className="product-search-container">
        <p className='para'>Search By Product Name</p>
  <form className="product-search-form" onSubmit={handleSubmit}>
    <input  type="text" placeholder="Enter product name" style={{color:"white"}} value={searchTerm} onChange={handleChange} />
    <button type="submit">Search</button>
  </form>
  {loading && <p>Loading...</p>}
  {searchResults.length > 0 && (
    <div className="product-cards">
      {searchResults.map((product) => (
        <div key={product.id} className="product-card">
          <h3>{product.name}</h3>
          <p>{product.description}</p>
          <p>Category: {product.category}</p>
          <p>Created Time: {product.createdTime}</p>
        </div>
      ))}
    </div>
  )}

  {/* {searchResults.length === 0 && <p className='para'> No results found</p>} */}
 
</div>

  );
};

export default ProductSearch;

