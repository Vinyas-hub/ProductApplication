import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Register.css';

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: ''
  });
  const navigate = useNavigate(); 
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8089/auth/register', formData);
      console.log('Registration Successful:', response.data);
      alert('Registration Successful!');
     navigate("/login");
    } catch (error) {
      console.error('Registration Failed:', error.response.data);
      alert('Registration Failed!');
      
    }
  };

  return (
    <div className='registration-container'>
    <h2>Registration</h2>
    <form onSubmit={handleSubmit}>
      <div>
        <label className="username-label">Username:</label>
        <input type="text" name="username" value={formData.username} onChange={handleChange} required />
      </div>
      <div>
        <label className="email-label">Email:</label>
        <input type="email" name="email" value={formData.email} onChange={handleChange} required />
      </div>
      <div>
        <label className="password-label">Password:</label>
        <input type="password" name="password" value={formData.password} onChange={handleChange} required />
      </div>
      <button className="register-button" type="submit">Register</button>
    </form>
  </div>
  
  );
};

export default RegistrationForm;

